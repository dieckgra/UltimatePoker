import java.util.Scanner;

public class SevenCardStud extends Game {

	static Scanner scanner = new Scanner(System.in);
	
	SevenCardStud() {
		super();
		sevenCardStud();
	}
	
	void sevenCardStud() {
		System.out.println("Seven Card Stud is not yet available!");
	}
}
