import java.util.Scanner;

public class TexasHoldem extends Game {
	static Scanner scanner = new Scanner(System.in);
	
	TexasHoldem() {
		super();
		texasHoldem();
	}
	
	void texasHoldem() {
		System.out.println("Texas Hold'em is not yet available!");
	}
}
